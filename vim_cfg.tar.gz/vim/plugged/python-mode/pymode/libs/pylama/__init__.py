"""Code audit tool for python.

:copyright: 2013 by Kirill Klenov.
:license: BSD, see LICENSE for more details.
"""

__version__ = "7.4.1"
__project__ = "pylama"
__author__ = "Kirill Klenov <horneds@gmail.com>"
__license__ = "GNU LGPL"
